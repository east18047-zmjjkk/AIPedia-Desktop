AIPedia Windows 便携版（x64）

解压整个 ZIP，然后双击 AIPedia.exe。默认浏览器会打开 AIPedia。
想从桌面启动，可以双击 Create-Desktop-Shortcut.cmd 创建 AIPedia 图标。
如果移动了解压后的文件夹，在新位置再运行一次创建脚本。
要退出，在 Windows 任务栏的通知区域右键点击 AIPedia 图标，选择「退出 AIPedia」。

知识词条、学习路径、站内搜索、公式和浏览器内 Python 示例可离线使用。
文内引用的外部网页和源资料需要联网打开。

如果浏览器没有自动打开，请手动访问 http://127.0.0.1:4322/。
如果旧版 AIPedia 还在运行，请先退出旧版，再打开新的桌面快捷方式。
如需查看启动日志，可以运行 Start-AIPedia.cmd。

本包包含 Node.js、KaTeX 和 Pyodide 运行时。
第三方许可见 third-party 和 site/vendor/pyodide 下随运行时提供的文件。
