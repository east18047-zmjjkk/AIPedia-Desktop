@echo off
setlocal DisableDelayedExpansion
set "AIPEDIA_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -NonInteractive -Command ^
 "$ErrorActionPreference = 'Stop';" ^
 "$folder = $env:AIPEDIA_PACKAGE_ROOT;" ^
 "$launcher = Join-Path $folder 'AIPedia.exe';" ^
 "$icon = Join-Path $folder 'aipedia.ico';" ^
 "if (!(Test-Path -LiteralPath $launcher -PathType Leaf)) { throw 'Extract the entire AIPedia ZIP before creating the shortcut.' }" ^
 "$desktop = [Environment]::GetFolderPath('DesktopDirectory');" ^
 "$path = Join-Path $desktop 'AIPedia.lnk';" ^
 "$shell = New-Object -ComObject WScript.Shell;" ^
 "$shortcut = $shell.CreateShortcut($path);" ^
 "if ((Test-Path -LiteralPath $path) -and ($shortcut.Description -ne 'AIPedia Desktop')) { throw 'An unrelated AIPedia shortcut already exists on the desktop.' }" ^
 "$shortcut.TargetPath = $launcher;" ^
 "$shortcut.Arguments = '';" ^
 "$shortcut.WorkingDirectory = $folder;" ^
 "if (Test-Path -LiteralPath $icon -PathType Leaf) { $shortcut.IconLocation = $icon + ',0' }" ^
 "$shortcut.Description = 'AIPedia Desktop';" ^
 "$shortcut.Save();" ^
 "Write-Output ('Desktop shortcut created: ' + $path)"
set "AIPEDIA_SHORTCUT_EXIT=%ERRORLEVEL%"
if /i not "%~1"=="--no-pause" pause
exit /b %AIPEDIA_SHORTCUT_EXIT%
