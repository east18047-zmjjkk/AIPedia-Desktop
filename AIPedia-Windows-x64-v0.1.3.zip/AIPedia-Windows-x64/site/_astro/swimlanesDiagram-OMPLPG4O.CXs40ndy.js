import{r as e,t}from"./chunk-QB3YPZ4I.BkoYrmgf.js";import"./chunk-TU62E6Q5.CfRlyKoV.js";import"./Mermaid.astro_astro_type_script_index_0_lang.RCT6mUEr.js";import"./chunk-HFQBQIA3.DUb3DLF7.js";import"./chunk-LEVMRMFU.DzObNKPC.js";import"./chunk-AXFCVDMN.B6lz1CXw.js";import"./chunk-X4PVCEUW.CUNnnBDI.js";import"./chunk-STOXU5M4.B_Nlcdbd.js";import"./chunk-R3KSYZAL.Cdi_1Y3M.js";import"./chunk-6MUBBAK2.Beojjn51.js";import"./chunk-BG4553SI.tG1sP603.js";import"./d3-selection.50GPHCQb.js";import{n}from"./chunk-Y2CYZVJY.DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};