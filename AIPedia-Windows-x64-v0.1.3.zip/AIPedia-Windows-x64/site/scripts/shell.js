/* ==========================================================================
   shell.js · 站壳交互（U2）
   代码块复制：为每个 Expressive Code 帧补 40px 标题栏 + 复制按钮
   （header 收缩与滚动相关逻辑已迁到 src/scripts/motion.js，U5）
   约束：无依赖、可 Tab 触发、不注入内联样式
   ========================================================================== */
(() => {
  'use strict';

  /* ---------- 2. 代码块复制 ---------- */
  const COPY_ICON =
    '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="1.6" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"></rect>' +
    '<path d="M5 15V5h10"></path></svg>';

  function ensureHeader(frame, pre) {
    let head = frame.querySelector('figcaption.header');
    if (head) return head;

    head = document.createElement('figcaption');
    head.className = 'header';

    const title = document.createElement('span');
    title.className = 'title';
    title.textContent = pre.getAttribute('data-language') || 'code';
    head.append(title);

    frame.insertBefore(head, pre);
    frame.classList.add('has-title');
    return head;
  }

  function attachCopy(frame) {
    const pre = frame.querySelector('pre');
    if (!pre) return;

    const head = ensureHeader(frame, pre);
    if (head.querySelector('.code-copy')) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'code-copy';
    btn.setAttribute('aria-label', '复制代码');
    btn.innerHTML = COPY_ICON;

    btn.addEventListener('click', async () => {
      const text = pre.innerText.replace(/\u00a0/g, ' ');
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        dispatchEvent(new CustomEvent('aipedia:toast', { detail: '复制失败，请手动选择' }));
        return;
      }
      btn.dataset.copied = 'true';
      btn.setAttribute('aria-label', '已复制');
      dispatchEvent(new CustomEvent('aipedia:toast', { detail: '代码已复制' }));
      setTimeout(() => {
        btn.dataset.copied = 'false';
        btn.setAttribute('aria-label', '复制代码');
      }, 1600);
    });

    head.append(btn);
  }

  document.querySelectorAll('.expressive-code .frame').forEach(attachCopy);
})();
