(() => {
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const sections = new Set(['a', 'b', 'c', 'd', 'e']);
  const homeDestinations = new Set([...sections, 'paths', 'reference']);

  function determineTransition(from, to) {
    if (!from || !to || motion.matches) return;
    const source = new URL(from);
    const destination = new URL(to);
    if (source.origin !== destination.origin) return;
    const previous = source.pathname.split('/')[1];
    const next = destination.pathname.split('/')[1];
    if (!previous && homeDestinations.has(next)) return 'from-home';
    if (previous !== next && sections.has(previous) && sections.has(next)) return 'across-sections';
  }

  function configure(transition, type) {
    if (type && transition.types) transition.types.add(type);
    else transition.skipTransition();
  }

  addEventListener('pageswap', ({ viewTransition, activation }) => {
    if (!viewTransition) return;
    configure(viewTransition, determineTransition(activation?.from?.url, activation?.entry?.url));
  });

  const entry = performance.getEntriesByType('navigation')[0];
  const referrer = entry?.type === 'navigate' ? document.referrer : '';

  function playArrival(type) {
    if (type && !motion.matches) document.documentElement.dataset.sectionArrival = type;
  }

  addEventListener('pagereveal', ({ viewTransition }) => {
    const activation = window.navigation?.activation;
    const type = determineTransition(activation?.from?.url || referrer, location.href);
    if (viewTransition) {
      configure(viewTransition, type);
      viewTransition.ready.catch(() => playArrival(type));
    } else {
      playArrival(type);
    }
  });

  if (!CSS.supports('selector(:active-view-transition-type(from-home))')) {
    playArrival(determineTransition(referrer, location.href));
  }
})();
