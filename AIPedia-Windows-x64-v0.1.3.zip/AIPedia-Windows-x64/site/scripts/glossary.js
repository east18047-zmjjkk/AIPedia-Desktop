(() => {
  const terms = document.querySelectorAll('span.ap-term[data-term-definition]');
  if (!terms.length) return;

  const card = document.createElement('div');
  card.id = 'ap-term-card';
  card.className = 'ap-term-card';
  card.setAttribute('role', 'tooltip');
  card.hidden = true;
  const label = document.createElement('strong');
  const english = document.createElement('p');
  english.className = 'ap-term-english';
  english.lang = 'en';
  english.hidden = true;
  const explanation = document.createElement('p');
  explanation.id = 'ap-term-meaning';
  const hint = document.createElement('p');
  hint.id = 'ap-term-more-hint';
  hint.className = 'ap-term-hint';
  hint.textContent = '点击或按回车，展开例子和补充解释';
  const details = document.createElement('div');
  details.id = 'ap-term-details';
  details.className = 'ap-term-details';
  hint.hidden = details.hidden = true;
  card.append(label, english, explanation, hint, details);
  document.body.append(card);

  for (const term of terms) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = term.className;
    Object.assign(button.dataset, term.dataset);
    button.setAttribute('aria-expanded', 'false');
    button.append(...term.childNodes);
    term.replaceWith(button);
  }

  const triggerOf = (target) => target instanceof Element ? target.closest('button.ap-term') : null;
  const contains = (element, target) => target instanceof Node && element.contains(target);
  let active = null;
  let pinned = false;
  let closeTimer;

  function appendNote(text, className) {
    if (!text) return;
    const note = document.createElement('p');
    note.className = className;
    note.textContent = text;
    details.append(note);
  }

  function renderDetails() {
    details.replaceChildren();
    if (!active.dataset.termDetails) return;
    const data = JSON.parse(active.dataset.termDetails);
    appendNote(data.example, 'ap-term-example');
    appendNote(data.sequence, 'ap-term-sequence');
    appendNote(data.formula, 'ap-term-formula');
    if (!data.terms?.length) return;
    const heading = document.createElement('strong');
    heading.textContent = '这几个词也一起看';
    const list = document.createElement('dl');
    for (const [term, definition] of data.terms) {
      const name = document.createElement('dt');
      const meaning = document.createElement('dd');
      name.textContent = term;
      meaning.textContent = definition;
      list.append(name, meaning);
    }
    details.append(heading, list);
  }

  function close() {
    clearTimeout(closeTimer);
    if (active) {
      active.setAttribute('aria-expanded', 'false');
      active.removeAttribute('aria-describedby');
      active.removeAttribute('aria-controls');
    }
    active = null;
    pinned = false;
    card.hidden = true;
  }

  function position() {
    if (!active) return;
    const anchor = active.getBoundingClientRect();
    const viewport = document.documentElement;
    if (anchor.bottom < 0 || anchor.top > viewport.clientHeight) {
      close();
      return;
    }
    const margin = 10;
    const gap = 6;
    const width = card.offsetWidth;
    const height = card.offsetHeight;
    const below = anchor.bottom + gap;
    const above = anchor.top - height - gap;
    const top = below + height <= viewport.clientHeight - margin || above < margin ? below : above;
    const left = anchor.left + (anchor.width - width) / 2;
    card.style.left = Math.max(margin, Math.min(left, viewport.clientWidth - width - margin)) + 'px';
    card.style.top = Math.max(margin, Math.min(top, viewport.clientHeight - height - margin)) + 'px';
  }

  function show(trigger) {
    clearTimeout(closeTimer);
    if (trigger === active) return;
    close();
    active = trigger;
    label.textContent = trigger.dataset.termLabel;
    english.textContent = trigger.dataset.termEnglish ?? '';
    english.hidden = !english.textContent;
    explanation.textContent = trigger.dataset.termDefinition;
    card.classList.remove('ap-term-is-pinned');
    card.setAttribute('role', 'tooltip');
    card.removeAttribute('aria-label');
    card.scrollTop = 0;
    details.hidden = true;
    hint.hidden = !trigger.dataset.termDetails;
    card.hidden = false;
    active.setAttribute('aria-describedby', hint.hidden ? explanation.id : `${explanation.id} ${hint.id}`);
    position();
  }

  function closeAfterMove() {
    clearTimeout(closeTimer);
    if (pinned || active?.matches(':focus-visible')) return;
    closeTimer = setTimeout(close, 180);
  }

  document.addEventListener('pointerover', (event) => {
    if (event.pointerType !== 'mouse' || contains(card, event.target)) return;
    const trigger = triggerOf(event.target);
    if (trigger && !contains(trigger, event.relatedTarget) && !pinned) show(trigger);
  });
  document.addEventListener('pointerout', (event) => {
    if (event.pointerType !== 'mouse' || !active || triggerOf(event.target) !== active) return;
    if (!contains(active, event.relatedTarget) && !contains(card, event.relatedTarget)) closeAfterMove();
  });
  card.addEventListener('pointerenter', () => clearTimeout(closeTimer));
  card.addEventListener('pointerleave', (event) => {
    if (active && !contains(active, event.relatedTarget)) closeAfterMove();
  });
  document.addEventListener('focusin', (event) => {
    const trigger = triggerOf(event.target);
    if (trigger?.matches(':focus-visible')) show(trigger);
  });
  document.addEventListener('focusout', (event) => {
    if (active && triggerOf(event.target) === active && !card.matches(':hover') && !contains(card, event.relatedTarget)) close();
  });
  document.addEventListener('pointerdown', (event) => {
    if (active && !contains(active, event.target) && !contains(card, event.target)) close();
  });
  document.addEventListener('click', (event) => {
    const trigger = triggerOf(event.target);
    if (!trigger) return;
    if (trigger === active && pinned) {
      close();
      return;
    }
    show(trigger);
    pinned = active === trigger;
    if (pinned) {
      if (trigger.dataset.termDetails) {
        renderDetails();
        details.hidden = false;
        hint.hidden = true;
        card.classList.add('ap-term-is-pinned');
        card.setAttribute('role', 'region');
        card.setAttribute('aria-label', trigger.dataset.termLabel + '的补充解释');
        trigger.setAttribute('aria-controls', details.id);
        trigger.setAttribute('aria-describedby', `${explanation.id} ${details.id}`);
      }
      trigger.setAttribute('aria-expanded', 'true');
      position();
    }
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && active) close();
  });
  window.addEventListener('resize', position);
  window.addEventListener('scroll', position, { capture: true, passive: true });
})();
