import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const site = fileURLToPath(new URL('./site', import.meta.url));
const port = Number(process.env.AIPEDIA_PORT || 4322);
const origin = 'http://127.0.0.1:' + port;
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.wasm': 'application/wasm',
  '.xml': 'application/xml',
};

async function serve(request, response) {
  if (request.headers.host !== '127.0.0.1:' + port) {
    response.writeHead(403).end();
    return;
  }
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.writeHead(405, { Allow: 'GET, HEAD' }).end();
    return;
  }
  let pathname;
  try {
    const url = new URL(request.url, origin);
    if (url.origin !== origin) throw new Error('Unexpected origin');
    pathname = decodeURIComponent(url.pathname);
    if (/[\0\\:]/.test(pathname)) throw new Error('Invalid path');
  } catch {
    response.writeHead(400).end();
    return;
  }
  let file = resolve(site, '.' + pathname);
  if (file !== site && !file.startsWith(site + sep)) {
    response.writeHead(403).end();
    return;
  }
  let status = 200;
  let details;
  try {
    details = await stat(file);
    if (details.isDirectory()) {
      if (!pathname.endsWith('/')) {
        response.writeHead(301, { Location: new URL(origin + pathname + '/').pathname }).end();
        return;
      }
      file = resolve(file, 'index.html');
      details = await stat(file);
    }
    if (!details.isFile()) throw new Error('Not a file');
  } catch {
    file = resolve(site, '404.html');
    details = await stat(file);
    status = 404;
  }
  response.writeHead(status, {
    'Content-Type': mime[extname(file)] || 'application/octet-stream',
    'Content-Length': details.size,
    'X-Content-Type-Options': 'nosniff',
    'X-AIPedia-Desktop': '1',
  });
  if (request.method === 'HEAD') {
    response.end();
  } else {
    createReadStream(file).on('error', () => response.destroy()).pipe(response);
  }
}
const server = createServer((request, response) => {
  serve(request, response).catch(() => {
    if (response.headersSent) response.destroy();
    else response.writeHead(500).end();
  });
});
function openBrowser() {
  if (process.argv.includes('--no-browser')) return;
  spawn('rundll32.exe', ['url.dll,FileProtocolHandler', origin + '/'], {
    stdio: 'ignore',
    windowsHide: true,
  }).on('error', () => console.log('Open ' + origin + ' in your browser.'));
}

server.on('error', async (error) => {
  if (error.code === 'EADDRINUSE') {
    try {
      const response = await fetch(origin, { method: 'HEAD', signal: AbortSignal.timeout(1000) });
      if (response.ok && response.headers.get('X-AIPedia-Desktop') === '1') {
        console.log('AIPedia is already running at ' + origin);
        openBrowser();
        return;
      }
    } catch {
      // The port was occupied but did not respond as an AIPedia instance.
    }
  }
  console.error('Could not start AIPedia:', error.message);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  if (process.argv.includes('--parent-stdin')) {
    process.stdin.once('end', () => server.close());
    process.stdin.resume();
  }
  console.log('AIPedia is ready at ' + origin);
  console.log('Keep this window open. Press Ctrl+C to stop AIPedia.');
  openBrowser();
});
